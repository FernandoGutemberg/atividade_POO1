﻿class Program{
    static void Main(String[] args){
        for(int i = 100;i>=0;i--){
            Console.WriteLine(i);
        }
    }
}