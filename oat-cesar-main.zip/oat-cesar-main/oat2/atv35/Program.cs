﻿class Program{
    static void Main(String[] args){
        for(int i = 10;i<=100;i++){
            if(i % 10 == 0){
                Console.WriteLine("Múltiplo de 10! " + i);
            }
        }
    }
}