﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuestaoUmApostilaDois
{
    internal class Program
    {
        static void Main(string[] args)
        {
 


            Carro carro = new Carro();
            carro.Nome = "Gol";
            carro.Fabricante = "Volksvagem";
            carro.Chassi = "1010567891011";
            carro.Placa = "REE-1234";
            carro.Combustivel = "etanol";
            carro.Cor = "prata";
            carro.FabricacaoAno = "2013";
            carro.NomeProprietario = "Robert Alberto";

            Carro carro1 = new Carro();
            carro1.Nome = "Opala";
            carro1.Fabricante = "chevrolet";
            carro1.Chassi = "1515567891012";
            carro1.Placa = "BOL-1717";
            carro1.Combustivel = "gasolina";
            carro1.Cor = "Preto";
            carro1.FabricacaoAno = "1975";
            carro1.NomeProprietario = "Jucelino Almeida";

            Carro carro2 = new Carro();
            carro2.Nome = "Fordka";
            carro2.Fabricante = "Ford";
            carro2.Chassi = "1719567891013";
            carro2.Placa = "LUL-1313";
            carro2.Combustivel = "Alcool";
            carro2.Cor = "Vermelho";
            carro2.FabricacaoAno = "2010";
            carro2.NomeProprietario = "Claudio Silva";

            Console.WriteLine(carro.Nome);
            Console.WriteLine(carro.Fabricante);
            Console.WriteLine(carro.Chassi);
            Console.WriteLine(carro.Placa);
            Console.WriteLine(carro.Combustivel);
            Console.WriteLine(carro.Cor);
            Console.WriteLine(carro.FabricacaoAno);
            Console.WriteLine(carro.NomeProprietario);
            Console.WriteLine();

            Console.WriteLine(carro1.Nome);
            Console.WriteLine(carro1.Fabricante);
            Console.WriteLine(carro1.Chassi);
            Console.WriteLine(carro1.Placa);
            Console.WriteLine(carro1.Combustivel);
            Console.WriteLine(carro1.Cor);
            Console.WriteLine(carro1.FabricacaoAno);
            Console.WriteLine(carro1.NomeProprietario);
            Console.WriteLine();

            Console.WriteLine(carro2.Nome);
            Console.WriteLine(carro2.Fabricante);
            Console.WriteLine(carro2.Chassi);
            Console.WriteLine(carro2.Placa);
            Console.WriteLine(carro2.Combustivel);
            Console.WriteLine(carro2.Cor);
            Console.WriteLine(carro2.FabricacaoAno);
            Console.WriteLine(carro2.NomeProprietario);
            Console.WriteLine();


            Console.ReadLine();
        }
    }
}
