﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuestaoUmApostilaDois

{
    internal class Carro
    {
        public string Nome { get; set; }
        public string Fabricante { get; set; }
        public string FabricacaoAno { get; set; }
        public string Placa { get; set; }
        public string Chassi { get; set; }
        public string Cor { get; set; }
        public string NomeProprietario { get; set; }
        public string Combustivel { get; set; }
    }
}
