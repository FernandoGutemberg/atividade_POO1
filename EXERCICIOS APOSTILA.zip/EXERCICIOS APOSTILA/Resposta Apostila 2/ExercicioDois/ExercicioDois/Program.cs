﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioDois
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Carro objCarro1 = new Carro();
            objCarro1.IdCarro = 1;
            objCarro1.marca = "Chevrollet";
            objCarro1.nome = "Corsa";
            objCarro1.cor = "Azul";
            objCarro1.numeroPassageiros = 5;
            objCarro1.modelo = "Wind";

            Console.WriteLine("//*********************************//");
            var listaRetorno1 = getPropertyValues(objCarro1);
            foreach (var item in listaRetorno1)
            {
                Console.WriteLine(item.Value.ToString());
            }

            Carro objCarro2 = new Carro()
            {
                IdCarro = 2,
                marca = "Honda",
                nome = "CIVIC", 
                cor = "Branca",
                numeroPassageiros = 5,
                modelo = "Sedan",
            };

            Console.WriteLine("//*********************************//");
            var listaRetorno2 = getPropertyValues(objCarro2);
            foreach (var item in listaRetorno2)
            {
                Console.WriteLine(item.Value.ToString());
            } 

            Carro objCarro3 = new Carro();
            objCarro1.IdCarro = 3;
            objCarro1.marca = "Honda";
            objCarro1.modelo = "Civic";
            objCarro1.cor = "Branca";
            objCarro1.numeroPassageiros = 5;
            objCarro1.modelo = "Sport";

            Console.WriteLine("//*********************************//");
            var listaRetorno3 = getPropertyValues(objCarro3);
            foreach (var item in listaRetorno3)
            {
                Console.WriteLine(item.Value.ToString());
            }

            int numeroCarro = 0;
            string resultado = string.Empty;
            int Contador = 0;
            do
            {
                if (Contador != 0)
                {
                    Console.WriteLine("Voce errou");
                    Console.WriteLine("//******Digite 1 para o {0}********************", objCarro1.nome);
                    Console.WriteLine("//******Digite 2 para o {0}********************", objCarro2.nome);
                    Console.WriteLine("//******Digite 3 para o {0}********************", objCarro3.nome);
                }
                else
                {
                    Console.WriteLine("//***********ESCOLHA QUAL CARRO VOCE QUER CONTROLAR***************//");
                    Console.WriteLine("//******Digite 1 para o {0}********************", objCarro1.nome);
                    Console.WriteLine("//******Digite 2 para o {0}********************", objCarro2.nome);
                    Console.WriteLine("//******Digite 3 para o {0}********************", objCarro3.nome);
                }
            }


        }
        public static Dictionary<string, object> getPropertyValues( object carro)
        {
            Dictionary<string, object> propertyValues = new Dictionary<string, object>();

            Type ObjecType = carro.GetType();
            System.Reflection.PropertyInfo[] properties = ObjectType.GetProperties();
            foreach (System.Reflection.PropertyInfo property in properties)
            {
                propertyValues.Add(property.Name, property.GetValue(carro, null));
            }

            return propertyValues; 

        }
    }
}
