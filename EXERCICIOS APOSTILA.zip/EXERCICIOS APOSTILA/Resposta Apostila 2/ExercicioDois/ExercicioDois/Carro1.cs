﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioDois
{
    public class Carro
    {
        public int IdCarro { get; set; }
        public string nome { get; set; }
        
        public string marca { get; set; }

        public string cor { get; set; }

        public string numeroPassageiros { get; set; }

        public string modelo { get; set; }

    }
}
